<?php $__env->startSection('content'); ?>
<main class="page-content">
  <!--breadcrumb-->
  <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
    <div class="breadcrumb-title pe-3">Tables</div>
    <div class="ps-3">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0 p-0">
          <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">All Employee</li>
        </ol>
      </nav>
    </div>
    <div class="ms-auto">
  
    </div>
  </div>
  <!--end breadcrumb-->

     <div class="card">
       <div class="card-body">
         <div class="d-flex align-items-center">
            <h5 class="mb-0">All Employee</h5>
             
         </div>
         <div class="table-responsive mt-3">
           <table class="table align-middle">
             <thead class="table-secondary">
               <tr>
                <th>#</th>
                <th>Name</th>
                <th>phone</th>
                <th>salary</th>
                <th>action</th>
               </tr>
             </thead>
             <tbody>
               <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
               <tr>
                <td> <?php echo e($row->id); ?> </td>
                 <td>
                   <div class="d-flex align-items-center gap-3 cursor-pointer">
                      <img src=" <?php echo e($row->photo); ?> " class="rounded-circle" width="44" height="44" alt="">
                      <div class="">
                        <p class="mb-0"><?php echo e($row->name); ?></p>
                      </div>
                   </div>
                 </td>
                 <td><?php echo e($row->phone); ?></td>
                 <td><?php echo e($row->salary); ?></td>
                
                 <td>
                   <div class="table-actions d-flex align-items-center gap-3 fs-6">
                  
                     <a href=" <?php echo e(URL::to('edit-employee/'.$row->id)); ?> " class="text-warning"  data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-fill"></i></a>

                     <a href=" <?php echo e(URL::to('delete-employee/'.$row->id)); ?> " id="delete" class="text-danger"  data-bs-placement="bottom" title="Delete"><i class="bi bi-trash-fill"></i></a>
                   </div>
                 </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
           </table>
         </div>
       </div>
     </div>


     

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>