<?php $__env->startSection('content'); ?>
    <main class="page-content">
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Dominate</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Pos (point of sale) </li>
                    </ol>
                </nav>
            </div>
            <div class="ms-auto">
                <div class="btn-group">
                    
                </div>
            </div>
        </div>
        </div>
        <!--end breadcrumb-->

        <div class="row">
            <div class="col-12 col-lg-5 d-flex">
                <div class="card w-100">
                    <div class="card-header py-3">
                        <h5 class="mb-0">Order product</h5>
                    </div>
                    <div class="card-body">
                            <div class="card-body">


                                <div class="table-responsive">
                                    <table class="table align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Product ID</th>
                                                <th>Product name </th>
                                                <th>Product Qty </th>
                                                <th>Sell Price</th>
                                                <th>total Price</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>

                                        <?php
                                            $product = Cart::content();
                                        ?>
                                        <tbody>
                                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <tr>
                                                    <td><?php echo e($prod->id); ?></td>
                                                    <td><?php echo e($prod->name); ?></td>

                                                    <td>
                                                        <form action="<?php echo e(url('/cart_update/'.$prod->rowId)); ?>" method="post">
                                                          <?php echo csrf_field(); ?>
                                                            <input type="number" name="qty" value="<?php echo e($prod->qty); ?>" style="width: 40px">
                                                            <button type="submit" class="btn btn-sm"style="background-color: green"  > <i class="lni lni-target" style="color:black"></i> </button>
                                                         </form>
                                                    </td>

                                                    <td><?php echo e($prod->price); ?></td>
                                                    <td><?php echo e($prod->price*$prod->qty); ?></td>

                                                    <td>
                                                        <div class="d-flex align-items-center gap-3 fs-6">
                                                            <a href=" <?php echo e(URL::to('/cart_remove/'.$prod->rowId)); ?> " class="text-danger" data-bs-placement="bottom"><i class="bi bi-trash-fill"></i></a>
                                                        </div>
                                                    </td>
                                                </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>



                            </div>

                            <div class="col">
                                <div class="card rounded-0 bg-success">
                                    <div class="card-body">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item text-white bg-transparent border-light-1"
                                                style="font-size: 25px"><i class="bi bi-check-circle me-2"></i>Quantity : <?php echo e(Cart::count()); ?>

                                            </li>
                                            <li class="list-group-item text-white bg-transparent border-light-1"
                                                style="font-size: 25px"><i class="bi bi-check-circle me-2"></i>Sub Total :  <?php echo e(Cart::subtotal()); ?>

                                            </li>
                                        </ul>
                                        <div class="text-center text-white">
                                            <h5 class="mb-4 text-white">Total</h5>
                                            <h1 class="card-price text-white">  <?php echo e(Cart::subtotal()); ?></h1>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        <form action=" <?php echo e(url('/create-invoice')); ?> " method="post">
                            <?php echo csrf_field(); ?>
                            <div class="col-12">
                                <div class="d-grid">
                                    <button class="btn btn-primary"> Product Confirm </button>
                                </div>
                            </div>
                        </form>




                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-7 d-flex">

                <div class="card w-100">
                    <div class="card-header py-3">
                        <div class="row g-3">
                            <h5 class="mb-0"> Add product </h5>
                            <div class="col-lg-4 col-md-6 me-auto">
                                
                            </div>
                            <div class="col-lg-2 col-6 col-md-3">
                                
                            </div>
                            <div class="col-lg-2 col-6 col-md-3">
                                
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>ID</th>
                                        <th>Customer name</th>
                                        <th>sell Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <form action=" <?php echo e(url('/add-cart')); ?> " method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($row->product_code); ?>">
                                                <input type="hidden" name="name" value="<?php echo e($row->product_name); ?>">
                                                <input type="hidden" name="qty" value="1">
                                                <input type="hidden" name="price" value="<?php echo e($row->sell_price); ?>">

                                                <td> <?php echo e($row->product_code); ?> </td>
                                                <td>
                                                    <div class="d-flex align-items-center gap-3 cursor-pointer">
                                                        <img src="  <?php echo e($row->product_image); ?> " class="rounded-circle"
                                                            width="44" height="44" alt="ZUBAIR">
                                                        <div class="">
                                                            <p class="mb-0"> <?php echo e($row->product_name); ?></p>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e($row->sell_price); ?></td>

                                                <td>
                                                    <button type="submit" class="btn btn-info btn-sm"><i
                                                            class="lni lni-link"></i></button>
                                                </td>

                                            </form>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </tbody>
                            </table>
                        </div>
                        <nav class="float-end" aria-label="Page navigation">
                            
                        </nav>
                    </div>
                </div>
            </div>





        </div>
        <!--end row-->

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>